import os
import random

def test_web_ui():

    # Sort out how best to do this... selenium?

    assert True
